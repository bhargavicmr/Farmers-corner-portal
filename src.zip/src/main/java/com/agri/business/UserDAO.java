package com.agri.business;
 
import java.sql.*;
 
public class UserDAO {
 
    public String checkLogin(String userName, String password) throws SQLException,
            ClassNotFoundException {
        String jdbcURL = "jdbc:mysql://localhost:3306/agri";
        String dbUser = "root";
        String dbPassword = "password";
 
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
        String sql = "SELECT * FROM users WHERE user_name = ? and password = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, userName);
        statement.setString(2, password);
 
        ResultSet result = statement.executeQuery();
 
        String username = null;

        if (result.next()) {
            username = result.getString("fullname");
        }

        connection.close();
 
        return username;
    }
}