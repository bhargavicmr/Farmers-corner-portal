package com.agri.business;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/login")
public class UserLoginServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    public UserLoginServlet()
    {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        String userType = request.getParameter("userType");

        UserDAO userDao = new UserDAO();

        try
        {
            userName = "bhargavi";//userDao.checkLogin(userName, password);
            String destPage = "login_home.jsp";

            if (userName != null)
            {
                HttpSession session = request.getSession();
                session.setAttribute("userName", userName);
                // for ex, if userType = 'admin' forwarding to admin.jsp
                destPage = userType + ".jsp";

                if(userType.equalsIgnoreCase("admin")) {
                    List<Order> orders = getOrders();
                    request.setAttribute("orders", orders);
                }

                if(userType.equalsIgnoreCase("farmer")) {
                    List<Order> orders = getOrders();
                    request.setAttribute("orders", orders);
                }

                if(userType.equalsIgnoreCase("customer")) {
                    List<Vegetable> vegetables = getVegetables();
                    request.setAttribute("vegetables", vegetables);
                }

            }
            else
            {
                String message = "Invalid userName/password";
                request.setAttribute("message", message);
            }

            RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
            dispatcher.forward(request, response);

        }
        catch (Exception ex)
        {//(SQLException | ClassNotFoundException ex) {
            throw new ServletException(ex);
        }
    }

    private List<Vegetable> getVegetables()
    {
        List<Vegetable> vegetables = new ArrayList<>();
        vegetables.add(new Vegetable(1, "Carrot", "images/carrot.jpg"));
        vegetables.add(new Vegetable(2, "Broccoli", "images/broccoli.jpg"));
        vegetables.add(new Vegetable(3, "Spinach", "images/spinach.jpg"));
        vegetables.add(new Vegetable(4, "Potato", "images/potato.jpg"));
        vegetables.add(new Vegetable(5, "Tomato", "images/tomato.jpg"));
        return vegetables;
    }

    private List<Order> getOrders()
    {
        List<Order> orders = new ArrayList<>();
        orders.add(new Order("farmer1", "Carrot", "10 kg", "bhargavi", "2/2/2024"));
        orders.add(new Order("farmer1","Broccoli", "2 pieces", "bhargavi","2/2/2024"));
        orders.add(new Order("farmer2","Tomato", "2 kg", "bannu","2/2/2024"));
        orders.add(new Order("farmer3","Potato", "200 gm", "kittu","2/2/2024"));
        orders.add(new Order("farmer2","Broccoli", "1 piece", "bannu", "2/2/2024"));
        return orders;
    }
}