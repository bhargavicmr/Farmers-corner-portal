package com.agri.business;

public class Order
{
    private String farmerName;
    private String vegetableName;
    private String orderBy;
    private String quantity;
    private String orderDate;

    public Order(String farmerName, String vegetableName, String quantity, String orderBy, String orderDate)
    {
        this.farmerName = farmerName;
        this.orderBy = orderBy;
        this.quantity = quantity;
        this.vegetableName = vegetableName;
        this.orderDate = orderDate;
    }

    public String getOrderBy()
    {
        return orderBy;
    }

    public void setOrderBy(String orderBy)
    {
        this.orderBy = orderBy;
    }

    public String getQuantity()
    {
        return quantity;
    }

    public void setQuantity(String quantity)
    {
        this.quantity = quantity;
    }

    public String getVegetableName()
    {
        return vegetableName;
    }

    public void setVegetableName(String vegetableName)
    {
        this.vegetableName = vegetableName;
    }

    public String getFarmerName()
    {
        return farmerName;
    }

    public void setFarmerName(String farmerName)
    {
        this.farmerName = farmerName;
    }

    public String getOrderDate()
    {
        return orderDate;
    }

    public void setOrderDate(String orderDate)
    {
        this.orderDate = orderDate;
    }
}